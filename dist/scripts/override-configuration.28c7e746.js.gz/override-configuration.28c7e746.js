'use strict';

angular.module('configuration.properties')
  .constant('overrideConfiguration', {
    apiBaseUrl: 'http://localhost:8000/api',

    oauthClientId: 'CwWuk2YE1v2LZIyKy2mvwyuhliYKHkKSxfhb0835'
  });

